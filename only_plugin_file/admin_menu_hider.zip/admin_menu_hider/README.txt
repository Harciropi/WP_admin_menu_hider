=== Admin menu hider ===
Contributors: harciropi
Tags: admin,menu,submenu,hide,role
Donate link: https://www.buymeacoffee.com/harciropi
Tested up to: 6.4.3
Stable tag: 1.2
License: GPLv2
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html

This plugin hides selected admin menu or sub-menu items from other users whose you want.

== Screenshots ==
1. The settings page.

== Changelog ==
V1.2 - latest
* Fixed a code error.

V1.1
* Submenu checkboxes affect to the parent too.
* Fixed a bug: Some menu does not disappear.

V1.0
* First release.